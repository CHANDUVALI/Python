


s= input("enter the string")



def findLength(s):
 
    
    count = 0
 
    for i in s:
        count+= 1
   
    return count
 

print(findLength(s))

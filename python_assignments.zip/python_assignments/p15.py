list1 = ['sois', 'manipal'];
list2 = [1, 2, 3, 4, 5, 6, 7 ];
print (list1[0] , list1[1])
print (list2[0:8], list2[1:5])
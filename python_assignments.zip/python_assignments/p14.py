
'''string length'''
string=input("Enter string:")
count=0
for i in string:
      count=count+1
print("Length of the string is:")
print(count)
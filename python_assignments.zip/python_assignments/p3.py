'''string concatination'''
string1 = input("Enter first string to concatenate: ");
string2 = input("Enter second string to concatenate: ");
string3 = string1 + string2;
print("\nString after concatenation =",string3);
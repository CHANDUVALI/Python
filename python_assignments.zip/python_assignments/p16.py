import sys
a=sys.argv[1]
b=sys.argv[2]
c=sys.argv[3]
sum = int(a)+ int (b) + int (c)
print(sum)